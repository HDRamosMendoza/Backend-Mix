﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen.Entitties
{
    public class Curso
    {
        public int CursoId { get; set; }
        public int GradoId { get; set; }
        public string Nombre { get; set; }
    }
}
