﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen.Entitties
{
    public class Notas
    {
        public int NotaId { get; set; }
        public int AlumnoId { get; set; }
        public int CursoId { get; set; }
        public int Nota { get; set; }
    }
}
