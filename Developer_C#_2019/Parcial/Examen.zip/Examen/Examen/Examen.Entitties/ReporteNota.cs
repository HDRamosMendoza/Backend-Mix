﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen.Entitties
{
    public class ReporteNota
    {
        public int ReporteNotaId { get; set; }
        public string Grado { get; set; }
        public string Curso { get; set; }
        public string Alumno { get; set; } 
        public int Nota { get; set; }
    }
}
