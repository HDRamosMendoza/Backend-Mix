﻿using System;
using Examen.Entitties;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Examen.Data.Test
{
    [TestClass]
    public class NotaDATest
    {
        [TestMethod]
        public void InsertNotas()
        {
            var da = new NotasDapperDA();
            var id = da.InsertArtist(new Notas()
                        {
                            AlumnoId = 3,
                            CursoId=1,
                            Nota=11
                        }
                    );
            Assert.IsTrue(id > 0);
        }
    }
}
