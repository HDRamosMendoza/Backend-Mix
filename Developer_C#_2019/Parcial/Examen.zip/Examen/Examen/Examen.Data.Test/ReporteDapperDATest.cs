﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Examen.Data.Test
{
    [TestClass]
    public class ReporteDapperDATest
    {
        [TestMethod]
        public void GetReporte()
        {
            var da = new ReporteDapperDA();
            var listado = da.GetReporte();
            Assert.IsTrue(listado.Count() > 0);
        }
    }
}
