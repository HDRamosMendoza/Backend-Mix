﻿using System;
using System.Linq;
using Examen.Entitties;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace Examen.Data.Test
{
    [TestClass]
    public class AlumnoDataTest
    {
        [TestMethod]
        public void GetListado()
        {
            var da = new AlumnoDA();
            var listado = da.Gets();
            Assert.IsTrue(listado.Count() > 0);
        }

        [TestMethod]
        public void InsertAlumno()
        {
            var da = new AlumnoDA();
            var id = da.InsertArtist(new Alumno() {
                Nombres = "Willy",
                Apellidos = "Urbina Salinas",
                Direccion = "Av LimaTambo",
                Sexo="M",
                FechaNacimiento=Convert.ToDateTime("1975-09-25")
            });
            Assert.IsTrue(id > 0);
        }
    }
}
