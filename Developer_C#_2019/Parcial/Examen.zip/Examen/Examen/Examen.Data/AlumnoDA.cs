﻿using Examen.Entitties;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen.Data
{
    public class AlumnoDA: BaseConnection
    {
        public IEnumerable<Alumno> Gets()
        {
            var result = new List<Alumno>();
            var sql = "SELECT AlumnoId, Nombres, Apellidos, Direccion, Sexo, FechaNacimiento FROM Alumno";
            
            using (IDbConnection cn = new SqlConnection(GetConection()))
            {
                cn.Open();
                IDbCommand cmd = new SqlCommand(sql);
                cmd.Connection = cn;
                var reader = cmd.ExecuteReader();
                var indice = 0;
                while (reader.Read())
                {
                    var entity = new Alumno();
                    indice = reader.GetOrdinal("AlumnoID");
                    entity.AlumnoId = reader.GetInt32(indice);

                    indice = reader.GetOrdinal("Nombres");
                    entity.Nombres = reader.GetString(indice);

                    indice = reader.GetOrdinal("Apellidos");
                    entity.Nombres = reader.GetString(indice);

                    indice = reader.GetOrdinal("Direccion");
                    entity.Nombres = reader.GetString(indice);

                    indice = reader.GetOrdinal("Sexo");
                    entity.Nombres = reader.GetString(indice);

                    result.Add(entity);
                }
            }

            return result;
        }

        public int InsertArtist(Alumno entity)
        {
            var result = 0;
            var sql = "usp_InsertAlumno";

            /* 1. Crear el objeto connection. */
            using (IDbConnection cn = new SqlConnection(GetConection()))
            {
                cn.Open();
                IDbCommand cmd = new SqlCommand(sql);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = cn;
                cmd.Parameters.Add(new SqlParameter("@Nombres", entity.Nombres));
                cmd.Parameters.Add(new SqlParameter("@Apellidos", entity.Apellidos));
                cmd.Parameters.Add(new SqlParameter("@Direccion", entity.Direccion));
                cmd.Parameters.Add(new SqlParameter("@Sexo", entity.Sexo));
                cmd.Parameters.Add(new SqlParameter("@FechaNacimiento", entity.FechaNacimiento));
                result = Convert.ToInt32(cmd.ExecuteScalar());

            }
            return result;
        }
    }
}
