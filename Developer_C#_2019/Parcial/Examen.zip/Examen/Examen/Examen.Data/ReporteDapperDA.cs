﻿using Dapper;
using Examen.Entitties;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen.Data
{
    public class ReporteDapperDA : BaseConnection
    {
        public IEnumerable<ReporteNota> GetReporte()
        {
            var result = new List<ReporteNota>();
            var sql = "SELECT Nombres,Apellidos "+
                        "FROM  Notas, Alumno,Curso, Grado "+
                        "Where "+
                        "Notas.AlumnoID = Alumno.AlumnoID AND "+
                        "Notas.CursoID = Curso.CursoID AND " +
                        "Curso.GradoID = Grado.GradoID AND " +
                        "Grado.Nivel = '1' AND " +
                        "Notas.Nota = 11";

            /* 1. Crear el objeto connection. */
            using (IDbConnection cn = new SqlConnection(GetConection()))
            {
                result = cn.Query<ReporteNota>(sql).ToList();
            }

            return result;
        }
    }
}
