﻿using Dapper;
using System;
using Examen.Entitties;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Examen.Data
{
    public class NotasDapperDA : BaseConnection
    {
        public int InsertArtist(Notas entity)
        {
            var result = 0;
            var sql = "usp_InsertNotas";

            /* 1. Crear el objeto connection. */
            using (IDbConnection cn = new SqlConnection(GetConection()))
            {
                result = cn.Query<int>(sql,
                    new
                    {
                        AlumnoId = entity.AlumnoId,
                        CursoId = entity.CursoId,
                        Nota = entity.Nota
                    },
                    commandType: CommandType.StoredProcedure).Single();

            }
            return result;
        }
    }
}
