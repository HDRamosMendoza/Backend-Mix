﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen.Data
{
    public class BaseConnection
    {
        public string GetConection()
        {
            return "Server=S000-00;DataBase=dbColegio;" +
                    "Password=sql; User ID=sa;";
        }
    }
}
