﻿using System;
using App.Data.DataAccess;
using App.Data.Repository.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace App.Data.Repository.Test
{
    [TestClass]
    public class ArtistRepositoryTest
    {
        [TestMethod]
        public void Count()
        {
            var _context = new DBDataModel();
            IArtistRepository rep = new ArtistRepository(_context);
            var count = rep.Count();

            Assert.IsTrue(count > 0);
        }
    }
}
