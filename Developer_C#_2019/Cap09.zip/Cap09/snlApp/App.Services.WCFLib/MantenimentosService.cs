﻿using App.Services.WCFLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Services.WCFLib
{
    public partial class MantenimentosService
                :IMantenimientosService
    {


    }
}
